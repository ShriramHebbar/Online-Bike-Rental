-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2017 at 07:57 PM
-- Server version: 5.6.26
-- PHP Version: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bikerental`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4', '2017-06-18 12:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE IF NOT EXISTS `tblbooking` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `VehicleId` int(11) DEFAULT NULL,
  `FromDate` varchar(20) DEFAULT NULL,
  `ToDate` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`) VALUES
(1, 'shriram@gmail.com', 2, '22/01/2022', '24/01/2022', 'book it', 1, '2022-01-10 23:56:39'),
(2, 'shriram@gmail.com', 3, '24/01/2022', '28/01/2022', 'book now.', 1, '2022-01-10 23:57:16'),
(3, 'viresh@gmail.com', 1, '22/01/2022', '24/01/2022', 'book', 1, '2022-01-11 00:02:13'),
(4, 'viresh@gmail.com', 4, '24/01/2022', '28/01/2022', 'book.', 2, '2022-01-11 00:02:32');

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE IF NOT EXISTS `tblbrands` (
  `id` int(11) NOT NULL,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(1, 'KTM', '2022-01-10 22:54:11', '2022-01-10 23:38:28'),
(2, 'Bajaj', '2022-01-10 22:56:32', NULL),
(3, 'Honda', '2022-01-10 22:57:51', NULL),
(4, 'Suzuki', '2022-01-10 22:58:28', NULL),
(5, 'Yamaha', '2022-01-10 22:59:15', NULL),
(7, 'Ducati', '2022-01-10 22:59:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

CREATE TABLE IF NOT EXISTS `tblcontactusinfo` (
  `id` int(11) NOT NULL,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, '2nd Railway Gate belgavi, India', 'bikerenterss@gmail.com', '9456987452');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE IF NOT EXISTS `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusquery`
--

INSERT INTO `tblcontactusquery` (`id`, `name`, `EmailId`, `ContactNumber`, `Message`, `PostingDate`, `status`) VALUES
(1, 'Shriram', 'shriram@gmail.com', '9291946465', 'In KTM , Duke390 :- Seats are a bit cramped', '2022-01-11 00:06:04', 1),
(2, 'viresh', 'viresh@gmail.com', '9291946466', 'In Suzuki , GSX-R1000 :- Service reach is limited', '2022-01-11 00:06:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE IF NOT EXISTS `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(1, 'Terms and Conditions', 'terms', '1. Terms of Use govern your use of this website and other services provided by "Bike Rental"  (the “Services“). These Terms of Use, together with our Privacy Policy and any other terms specifically referred to in any of those documents, constitute legally binding agreement (the “Agreement“) between You and GoBikes LLP in relation to your use of this website and services (together, the “Platform“). By accepting the terms and conditions you will be legally bound to follow all the below mentioned terms and conditions during your relationship with GoBikes LLP. If you disagree to any of the terms of this agreement, please refrain from hiring the bike.
2. Defined Terms:
    1. "Bike Rental" (hereinafter referred as the “Company“) is a registered limited liability partnership company in the state of Delhi, India. The registered address of the Company is 2nd Railway Gate belgavi, India
    2. “Conditions” mean these General Conditions of Use, to carry on the business of letting on hire or otherwise, motor cycle and other vehicles of every kind and description, on such terms and conditions as may be decided by the Company from time to time.
    3. “Service” refers to any service provided by the Company, as the Company deems fit, to any User.
    4. “User” means a person who has accepted the terms and conditions for leasing or renting a motor cycle or motor vehicle of any kind from the Company.
    5. “Vehicle” means the motor cycle/motor bike/scooter or motor vehicle of any kind offered by the Company to any User for leasing/renting for the period as determined between the Company and the User.
    6. These Conditions are intended to create binding rights and obligations between the User and the Company in accordance with the Indian Contract Act, 1872. The Company reserves the right to change the terms of these Conditions from time to time. No access to the Services will be permitted unless the Conditions are accepted in full. No User is entitled to accept only part of the Conditions. If a User does not agree to all the Conditions, such User may not use the Services. In the event that any Member fails to comply with any of the Conditions, the Company reserves the right, at its own discretion, to suspend or withdraw all Services to that User without notice.'),
(2, 'Privacy Policy', 'privacy', 'http://localhost/bikerental/  is a website owned and operated by CAFERIDES a Company duly registered and incorporated under the Companies Act, 1956, whose address is at 2nd Railway Gate belgavi, India
CAFERIDES strongly committed in protecting your privacy and has taken all necessary and reasonable measures to protect your information and handle the same in a safe and responsible manner in accordance with the terms and conditions of privacy policy set out herein below:"Bike Rental"
(the website) is a place where you can take on rent motor bikes. For you to rent the bike you need to sign up first. For Indian Customers register by providing full name, phone number, email, password, contact number and for Foreigners by providing full name, phone number, email, password, contact number, pincode and Nationality.
The information contained in this website and the information collected by using/ login and or accessing this website are stored at a secured server managed and owned by Amazon Web Services. It is stated by the server service provider that they have all the best security practices required for the server. The security and privacy practices of the server operator can be known from http://aws.amazon.com/privacy/."Bike Rental"
is not giving any warranties regarding the policies or practices of the server operator. Certain of such collected information are stored in CITYRIDES computers for processing your vehicle hire request, accounting and other operational purposes.
The website is owned by an Indian company and is located in India. Hence, we are duty bound to abide by the Indian privacy laws. This privacy policy is applicable to all users of this website. The user is herein collectively refereed as ‘You’. We may not have complied with some privacy laws of other countries. We do not know such legal requirements as well. Hence, if you are a foreign national and requires us to have different privacy practices in relation to your personal data, you are required to notify us before providing your personal data.
Your use of the website services constitute your consent to the terms of this Privacy Policy.
Collection of Information
For log in to the site and by hiring the vehicles, you may have to login by giving following details a) Email address b) Phone number c) Full name d) Password . For transacting business through this website you are required to provide the following information a) Email address b) Phone number c) Full name  d) Driving license e) Address ID . While using the vehicle on rent, our system collect the following data: driving license, address ID, work email address, GPS location of the bike, passport, and images of the customer. Some of these information are personally identifiable information and is collected for the purpose of verification of identity of the user and ensure due compliances. We use these information to monitor the usage of our websites and also whatever necessary for our business.
Information collected from third party: We may collect your personal information as well as other information from third parties like business partners, contractors etc. and add the same to our account information.'),
(3, 'About Us ', 'aboutus', '<span style="color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; text-align: justify;">WE ARE THE BIKE RENTAL MANAGER. The only 100% dedicated bike rental booking website. The first Bike Rental Manager (BRM) shop was our own bike shop. Ever Since it has been our aim to make bike rental easier for everyone, everywhere.We focus on making bike rentals easier for you.Your rental business has a unique set of challenges. We are the only dedicated bike rental site and will be able to offer you a solution to match your needs.Get in touch with us today! We provide affordable bike rates, we hae lost of Satiisfied customers feedback, you can have a look at our home page too!! </span>'),
(11, 'FAQs', 'faqs', '																														<span style="color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;">How do I use discounts coupons?
Except for promotion codes, Our discounts are applied automatically if your reservation meets any of the criteria mentioned above.

To use a promotion code, simply enter the code on the homepage widget as you start your reservation. You can do this by selecting the "Have a promotion code?" prompt. Promotion codes can also be entered on the checkout page, under Reservation Total. Please note that the promotion code prompt does not appear for certain types of reservations, such as reservations made on the Deals page.
<br>
Our Discounts Terms & Conditions
We no longer offer or accept returning customer discounts. All discounts are non-transferable and cannot be combined with additional promotions or discounts.</br>

* Liability in case accident:
The hirer should have coverage through his own accident and liability insurance.
The renting company is not responsible under any circumstances for accidents or damages caused to the hirer or which the hirer causes to any third party or cases of liability </span>');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE IF NOT EXISTS `tblsubscribers` (
  `id` int(11) NOT NULL,
  `SubscriberEmail` varchar(120) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubscribers`
--

INSERT INTO `tblsubscribers` (`id`, `SubscriberEmail`, `PostingDate`) VALUES
(1, '	shriram@gmail.com', '2022-01-10 23:57:41'),
(2, '	viresh@gmail.com', '2022-01-11 22:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbltestimonial`
--

CREATE TABLE IF NOT EXISTS `tbltestimonial` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Testimonial` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltestimonial`
--

INSERT INTO `tbltestimonial` (`id`, `UserEmail`, `Testimonial`, `PostingDate`, `status`) VALUES
(1, 'shriram@gmail.com', 'I think this is the one and only top bike rental site in the world. 5-Stars from me - Full satisfaction, no complain at all', '2022-01-10 23:59:18', 1),
(2, 'viresh@gmail.com', 'Great Website for bike rental at affordable prize.', '2022-01-11 00:04:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE IF NOT EXISTS `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(1, 'Shriram', 'shriram@gmail.com', 'fe1d2f53ac8add6fd390fbb6f980b03d', '9435486324', '28/07/2001', '2nd Railway Gate..', 'belgavi', 'India', '2022-01-10 23:56:11', '2022-01-11 19:10:21'),
(2, 'viresh', 'viresh@gmail.com', 'f7feae0085bc1c32bbe2b2583f9c7cc7', '9435486328', '22/07/2001', '4th Railway Gate', 'belgavi', 'India', '2022-01-11 00:01:50', '2022-01-12 19:15:21');


-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE IF NOT EXISTS `tblvehicles` (
  `id` int(11) NOT NULL,
  `VehiclesTitle` varchar(150) DEFAULT NULL,
  `VehiclesBrand` int(11) DEFAULT NULL,
  `VehiclesOverview` longtext,
  `PricePerDay` int(11) DEFAULT NULL,
  `FuelType` varchar(100) DEFAULT NULL,
  `ModelYear` int(6) DEFAULT NULL,
  `SeatingCapacity` int(11) DEFAULT NULL,
  `Vimage1` varchar(120) DEFAULT NULL,
  `Vimage2` varchar(120) DEFAULT NULL,
  `Vimage3` varchar(120) DEFAULT NULL,
  `Vimage4` varchar(120) DEFAULT NULL,
  `Vimage5` varchar(120) DEFAULT NULL,
  `AirConditioner` int(11) DEFAULT NULL,
  `PowerDoorLocks` int(11) DEFAULT NULL,
  `AntiLockBrakingSystem` int(11) DEFAULT NULL,
  `BrakeAssist` int(11) DEFAULT NULL,
  `PowerSteering` int(11) DEFAULT NULL,
  `DriverAirbag` int(11) DEFAULT NULL,
  `PassengerAirbag` int(11) DEFAULT NULL,
  `PowerWindows` int(11) DEFAULT NULL,
  `CDPlayer` int(11) DEFAULT NULL,
  `CentralLocking` int(11) DEFAULT NULL,
  `CrashSensor` int(11) DEFAULT NULL,
  `LeatherSeats` int(11) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(1, 'Pulsar SS400', 2, 'Slowly spreading its cards this year, the Ace of Bajaj Autos is still not on the table. With the expectations like Pulsar 400SS or Pulsar SS400, the Ace (400SS) would be the commander of the Pulsar series. It would be a benchmark for the other motorcycle manufacturers as the competition for more performance oriented bikes will definitely rise this year.',12, 'Petrol',2015, 2, 'knowledges_base_bg.jpg', 'pulsar-ss400-17.jpg', 'Pulsar-SS400-8-1200x675.jpg', 'bajaj-pulsar-400ss-mk.jpg', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2022-01-09 22:57:35', '2022-01-10 23:37:35'),
(2, 'RS200', 2, 'The Pulsar is by far the most successful brand Bajaj has managed to create in the recent past.It is also fast, no doubt. But, its true highlight is its easy to ride nature. ', 15, 'Petrol', 2010, 2, 'bike_755x430.png', 'Bajaj-Pulsar-RS-200-Price-In-India-1.jpg', 'bike_755x430.png', 'Pulsar-RS-200-tank-and-fairing.jpg', '', 1, 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, NULL, '2022-01-09 23:40:15', '2022-01-10 23:41:54'),
(3, 'GSX-R1000', 4, ' The Suzuki GSX-R1000 is a sport bike from Suzuki GSX-R series of motorcycles.It was introduced in 2001 to replace the GSX-R1100 and is powered by a liquid-cooled 999 cc (61.0 cu in) inline four-cylinder, four-stroke engine.', 9, 'Petrol', 2017, 2, 'featured-img-300.jpg', 'suzuki-5929389__340.jpg', 'suzuki-4994541__340.jpg', 'bike-4056616__480.jpg', '', 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, NULL, NULL, '2022-01-09 23:38:58', '2022-01-10 23:40:28'),
(4, 'Duke390', 1, ' The KTM 390 DUKE breathes life into values that have made motorcycling so amazing for decades. It combines maximum riding pleasure with optimum user value and comes out on top wherever nimble handling counts. Light as a feather, powerful and packed with state-of-the-art technology, it guarantees a thrilling ride, whether youre in the urban jungle or a forest of bends. 390 DUKE – nowhere you will find more motorcycle per euro.', 12, 'Petrol', 2015, 2, 'featured-img-3000.jpg', 'lest-side-view-744666144_300x200.webp', 'duke.jpg', 'rear-left-view-567991743_300x200.webp', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, NULL, NULL, NULL, '2022-01-09 23:41:38', '2022-01-10 23:42:56'),
(5, 'R1', 5, 'The YZF-R1® features a lightweight and compact crossplane crankshaft, inline-four-cylinder, 998cc high output engine. Featuring titanium fracture-split connecting rods, an offset cylinder block and magnesium covers, the motor delivers extremely high horsepower and a strong pulse of linear torque for outstanding performance, all wrapped in aerodynamic MotoGP®-style bodywork.', 10, 'Petrol', 2012, 2, 'bikes_755x430.png', 'image.jpg','images1.jpg', 'i1.jpg', '', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2022-01-09 23:40:31', '2022-01-10 23:41:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbrands`
--
ALTER TABLE `tblbrands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tblbrands`
--
ALTER TABLE `tblbrands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tblcontactusinfo`
--
ALTER TABLE `tblcontactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `tblsubscribers`
--
ALTER TABLE `tblsubscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbltestimonial`
--
ALTER TABLE `tbltestimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tblvehicles`
--
ALTER TABLE `tblvehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
